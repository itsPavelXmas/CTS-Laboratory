package ro.ase.cts.assignment.refactor;

public enum AccountTypes {
    STANDARD, BUDGET, PREMIUM, SUPER_PREMIUM;
}
