package ro.ase.cts.assignment.refactor;

public interface AccountInterface {
    public double getMonthlyRate();
}
